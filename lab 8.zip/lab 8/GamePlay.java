import javax.swing.JOptionPane;

public class GamePlay extends javax.swing.JFrame {
    int score = 0;
    String summary = "";
    String operation = "";
    
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton jButton_add;
    private javax.swing.JButton jButton_sub;
    private javax.swing.JButton jButton_div;
    private javax.swing.JButton jButton_mix;
    private javax.swing.JButton jButton_summary;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JButton jButton_submit;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;

    public GamePlay() {
        initComponents();
    }

    private void initComponents() {
        jPanel1 = new javax.swing.JPanel();
        jButton_add = new javax.swing.JButton();
        jButton_sub = new javax.swing.JButton();
        jButton_div = new javax.swing.JButton();
        jButton_mix = new javax.swing.JButton();
        jButton_summary = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jTabbedPane1.addTab("Game Panel", jPanel2);
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jButton_submit = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jScrollPane1.setViewportView(jTextArea1);
        jPanel3.add(jScrollPane1);
        jTabbedPane1.addTab("Summary Panel", jPanel3);
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButton_add.setText("Addition");
        jButton_add.addActionListener(evt -> jButton_addActionPerformed(evt));

        jButton_sub.setText("Subtraction");
        jButton_sub.addActionListener(evt -> jButton_subActionPerformed(evt));

        jButton_div.setText("Division");
        jButton_div.addActionListener(evt -> jButton_divActionPerformed(evt));

        jButton_mix.setText("Mixed");
        jButton_mix.addActionListener(evt -> jButton_mixActionPerformed(evt));

        jButton_summary.setText("Summary");
        jButton_summary.addActionListener(evt -> jButton_summaryActionPerformed(evt));

        jButton_submit.setText("Submit");
        jButton_submit.addActionListener(evt -> jButton_submitActionPerformed(evt));

        jLabel1.setText("Math Learning Game");
        jLabel2 = new javax.swing.JLabel();
        jLabel2.setText("");
        jPanel1.add(jLabel2);
        
        pack();
    }

    private void jButton_addActionPerformed(java.awt.event.ActionEvent evt) {
        operation = "+";
        jLabel2.setText(operation);
        jTabbedPane1.setSelectedIndex(0);
        int a = (int) (Math.random() * 20);
        int b = (int) (Math.random() * 20);
        jTextField1.setText(Integer.toString(a));
        jTextField2.setText(Integer.toString(b));
    }

    private void jButton_subActionPerformed(java.awt.event.ActionEvent evt) {
        operation = "-";
        jLabel2.setText(operation);
        jTabbedPane1.setSelectedIndex(0);
        int a = (int) (Math.random() * 20);
        int b = (int) (Math.random() * 20);
        if (b > a) { int temp = a; a = b; b = temp; }
        jTextField1.setText(Integer.toString(a));
        jTextField2.setText(Integer.toString(b));
    }

    private void jButton_divActionPerformed(java.awt.event.ActionEvent evt) {
        operation = "/";
        jLabel2.setText(operation);
        jTabbedPane1.setSelectedIndex(0);
        int a = (int) (Math.random() * 9) + 2;
        int b = (int) (Math.random() * 9) + 2;
        jTextField1.setText(Integer.toString(a));
        jTextField2.setText(Integer.toString(b));
    }

    private void jButton_mixActionPerformed(java.awt.event.ActionEvent evt) {
        int choice = (int) (Math.random() * 3);
        if (choice == 0) jButton_addActionPerformed(evt);
        else if (choice == 1) jButton_subActionPerformed(evt);
        else jButton_divActionPerformed(evt);
    }

    private void jButton_submitActionPerformed(java.awt.event.ActionEvent evt) {
        int a = Integer.parseInt(jTextField1.getText());
        int b = Integer.parseInt(jTextField2.getText());
        double actualResult;
        double userAnswer = Double.parseDouble(jTextField3.getText());

        if (operation.equals("+")) {
            actualResult = a + b;
            summary += "\n" + a + " + " + b + " = " + userAnswer + ": " + (actualResult == userAnswer);
        } else if (operation.equals("-")) {
            actualResult = a - b;
            summary += "\n" + a + " - " + b + " = " + userAnswer + ": " + (actualResult == userAnswer);
        } else {
            actualResult = (double) a / b;
            double roundedResult = Math.round(actualResult * 100.0) / 100.0;
            summary += "\n" + a + " / " + b + " = " + userAnswer + ": " + (roundedResult == userAnswer);
        }

        if (Math.abs(actualResult - userAnswer) < 0.01) {
            score++;
            JOptionPane.showMessageDialog(rootPane, "Correct!");
        } else {
            JOptionPane.showMessageDialog(rootPane, "Wrong!");
        }
        
        jTextField1.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
    }

    private void jButton_summaryActionPerformed(java.awt.event.ActionEvent evt) {
        jTabbedPane1.setSelectedIndex(1);
        jTextArea1.setText("Your score is: " + score + "\nSummary: " + summary);
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> {
            new GamePlay().setVisible(true);
        });
    }
}
