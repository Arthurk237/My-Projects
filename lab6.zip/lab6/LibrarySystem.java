abstract class LibraryItem {
    protected String title;
    protected int year;

    public LibraryItem(String title, int year) {
        this.title = title;
        this.year = year;
    }
    
    public abstract void getItemDetails();
}

// Part 2: Interface Loanable
interface Loanable {
    void checkout();
    void returnItem();
}

// Part 3: Concrete Classes
class Book extends LibraryItem implements Loanable {
    private String author;
    private boolean isAvailable = true;

    public Book(String title, int year, String author) {
        super(title, year);
        this.author = author;
    }

    @Override
    public void getItemDetails() {
        System.out.println("Book: " + title + " by " + author + ", Year: " + year + ", Available:" + isAvailable);
    }

    @Override
    public void checkout() {
        if (isAvailable) {
            isAvailable = false;
            System.out.println("Book '" + title + "' checked out.");
        } else {
            System.out.println("Book '" + title + "' is already checked out.");
        }
    }

    @Override
    public void returnItem() {
        isAvailable = true;
        System.out.println("Book '" + title + "' returned.");
    }
}

// Magazine class (not loanable)
class Magazine extends LibraryItem {
    private String genre;

    public Magazine(String title, int year, String genre) {
        super(title, year);
        this.genre = genre;
    }

    @Override
    public void getItemDetails() {
        System.out.println("Processing Item:");
        System.out.println("Magazine: " + title + ", Genre: " + genre + ", Year:" + year);
        System.out.println("Note: This item is for reference only and cannot be loaned");
        System.out.println("This item is not loanable.\n");
    }
}

// DVD class implementing Loanable
class DVD extends LibraryItem implements Loanable {
    private int duration;
    private boolean isAvailable = true;

    public DVD(String title, int year, int duration) {
        super(title, year);
        this.duration = duration;
    }

    @Override
    public void getItemDetails() {
        System.out.println("DVD: " + title + ", Year: " + year + ", Duration: " + duration + " minutes, Available:" + isAvailable);
    }

    @Override
    public void checkout() {
        if (isAvailable) {
            isAvailable = false;
            System.out.println("DVD '" + title + "' checked out.");
        } else {
            System.out.println("DVD '" + title + "' is already checked out.");
        }
    }

    @Override
    public void returnItem() {
        isAvailable = true;
        System.out.println("DVD '" + title + "' returned.");
    }
}

// Part 4: Testing the System
public class LibrarySystem {
    public static void processLibraryItem(LibraryItem item) {
        System.out.println("Processing Item:");
        item.getItemDetails();
        if (item instanceof Loanable) {
            Loanable loanableItem = (Loanable) item;
            loanableItem.checkout();
            loanableItem.returnItem();
        }
        
    }

    public static void main(String[] args) {
        LibraryItem book = new Book("The Alchemist", 1993, "Paulo Coelho");
        LibraryItem magazine = new Magazine("National Geographic", 2022, "Science");
        LibraryItem dvd = new DVD("Inception", 2010, 148);

        processLibraryItem(book);
        processLibraryItem(magazine);
        processLibraryItem(dvd);
    }
}
