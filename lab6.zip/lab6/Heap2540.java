public class Heap2540 {
    private String[] heap;
    private int n=0;
    
    public Heap2540(String[ ] a) {    	
     this.n = a.length;
        this.heap = new String[n + 1];
        System.arraycopy(a, 0, heap, 1, n);
            for (int i = n / 2; i >= 1; i--) {
                sink(i);
            }
    }
  
    public Heap2540() {   
    	heap=new String[128];
    }
  
    public String removeMax() {
    	String max=heap[1];
	swap(1, n);
        n--;
        sink(1);       
	return max;
    }

    public void insert(String x) {


    if (n >= heap.length - 1) {
        resize();
    }
    n++;
    heap[n] = x;
    swim(n);
  }
     

    private void swim(int k) {
       while (k > 1 && less(k / 2, k)) {
            swap(k, k / 2);
            k = k / 2;
        }
    } 
    
    
    private void swap(int i, int j) {
        String temp = heap[i];
        heap[i] = heap[j];
        heap[j] = temp;
    }

    private void sink(int k) {
        while (2 * k <= n) {
            int j = 2 * k;
            if (j < n && less(j, j + 1)) {
                j++;
            }
            if (!less(k, j)) {
                break;
            }
            swap(k, j);
                    k = j;
                }
            }
    

   
    private boolean less(int i, int j) {
        return heap[i].compareTo(heap[j]) < 0;
    }
    
    private void resize() {
        String[] newHeap = new String[heap.length * 2];
        System.arraycopy(heap, 0, newHeap, 0, heap.length);
        heap = newHeap;
    }

}

