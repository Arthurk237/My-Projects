import javax.swing.*;
import java.awt.*;

// ---------- Library Item Classes ----------

// Abstract class representing a library item
abstract class LibraryItem {
    protected String title;
    protected int year;

    public LibraryItem(String title, int year) {
        this.title = title;
        this.year = year;
    }
    
    // Modified to return a string instead of printing directly
    public abstract String getItemDetails();
}

// Loanable interface for items that can be loaned out
interface Loanable {
    void checkout();
    void returnItem();
}

// Book class implementing Loanable
class Book extends LibraryItem implements Loanable {
    private String author;
    private boolean isAvailable = true;

    public Book(String title, int year, String author) {
        super(title, year);
        this.author = author;
    }

    @Override
    public String getItemDetails() {
        return "Book: " + title + " by " + author + ", Year: " + year + ", Available: " + isAvailable;
    }

    @Override
    public void checkout() {
        if (isAvailable) {
            isAvailable = false;
            System.out.println("Book '" + title + "' checked out.");
        } else {
            System.out.println("Book '" + title + "' is already checked out.");
        }
    }

    @Override
    public void returnItem() {
        isAvailable = true;
        System.out.println("Book '" + title + "' returned.");
    }
}

// Magazine class (not loanable)
class Magazine extends LibraryItem {
    private String genre;

    public Magazine(String title, int year, String genre) {
        super(title, year);
        this.genre = genre;
    }

    @Override
    public String getItemDetails() {
        return "Magazine: " + title + ", Genre: " + genre + ", Year: " + year 
                + "\nNote: This item is for reference only and cannot be loaned.";
    }
}

// DVD class implementing Loanable
class DVD extends LibraryItem implements Loanable {
    private int duration;
    private boolean isAvailable = true;

    public DVD(String title, int year, int duration) {
        super(title, year);
        this.duration = duration;
    }

    @Override
    public String getItemDetails() {
        return "DVD: " + title + ", Year: " + year + ", Duration: " + duration 
                + " minutes, Available: " + isAvailable;
    }

    @Override
    public void checkout() {
        if (isAvailable) {
            isAvailable = false;
            System.out.println("DVD '" + title + "' checked out.");
        } else {
            System.out.println("DVD '" + title + "' is already checked out.");
        }
    }

    @Override
    public void returnItem() {
        isAvailable = true;
        System.out.println("DVD '" + title + "' returned.");
    }
}

// ---------- GUI Class ----------

public class LibraryGUI {
    public static void main(String[] args) {
        // Create the GUI on the Event Dispatch Thread for thread safety
        SwingUtilities.invokeLater(() -> new LibraryGUI().createAndShowGUI());
    }
    
    public void createAndShowGUI(){
        JFrame frame = new JFrame("Library System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 400);
        frame.setLayout(new BorderLayout(10, 10));
        
        // ----- Input Panel -----
        JPanel inputPanel = new JPanel(new GridLayout(0, 2, 5, 5));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Item type selection
        inputPanel.add(new JLabel("Item Type:"));
        String[] itemTypes = {"Book", "Magazine", "DVD"};
        JComboBox<String> itemTypeCombo = new JComboBox<>(itemTypes);
        inputPanel.add(itemTypeCombo);
        
        // Title field
        inputPanel.add(new JLabel("Title:"));
        JTextField titleField = new JTextField();
        inputPanel.add(titleField);
        
        // Year field
        inputPanel.add(new JLabel("Year:"));
        JTextField yearField = new JTextField();
        inputPanel.add(yearField);
        
        // Extra field (changes label based on selected item type)
        JLabel extraLabel = new JLabel("Author:"); // Default for Book
        inputPanel.add(extraLabel);
        JTextField extraField = new JTextField();
        inputPanel.add(extraField);
        
        // Update the extra label based on the selected item type
        itemTypeCombo.addActionListener(e -> {
            String selected = (String) itemTypeCombo.getSelectedItem();
            if(selected.equals("Book")){
                extraLabel.setText("Author:");
            } else if(selected.equals("Magazine")){
                extraLabel.setText("Genre:");
            } else if(selected.equals("DVD")){
                extraLabel.setText("Duration (min):");
            }
        });
        
        // ----- Output Area -----
        JTextArea outputArea = new JTextArea();
        outputArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(outputArea);
        
        // ----- Process Button -----
        JButton processButton = new JButton("Process Item");
        processButton.addActionListener(e -> {
            String type = (String) itemTypeCombo.getSelectedItem();
            String title = titleField.getText().trim();
            String yearText = yearField.getText().trim();
            String extra = extraField.getText().trim();
            
            // Validate input fields
            if(title.isEmpty() || yearText.isEmpty() || extra.isEmpty()){
                JOptionPane.showMessageDialog(frame, "Please fill in all fields.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            int year;
            try {
                year = Integer.parseInt(yearText);
            } catch(NumberFormatException ex){
                JOptionPane.showMessageDialog(frame, "Year must be a valid number.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            LibraryItem item = null;
            if(type.equals("Book")){
                item = new Book(title, year, extra);
            } else if(type.equals("Magazine")){
                item = new Magazine(title, year, extra);
            } else if(type.equals("DVD")){
                int duration;
                try {
                    duration = Integer.parseInt(extra);
                } catch(NumberFormatException ex){
                    JOptionPane.showMessageDialog(frame, "Duration must be a valid number.", "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                item = new DVD(title, year, duration);
            }
            
            // Build the output string
            StringBuilder details = new StringBuilder();
            details.append("Processing Item:\n");
            details.append(item.getItemDetails()).append("\n");
            
            // If the item is loanable, simulate checkout and return
            if(item instanceof Loanable) {
                ((Loanable)item).checkout();
                details.append("Item checked out.\n");
                ((Loanable)item).returnItem();
                details.append("Item returned.\n");
            }
            details.append("----------------------\n");
            
            // Append details to the output area
            outputArea.append(details.toString());
        });
        
        // ----- Arrange Panels in Frame -----
        frame.add(inputPanel, BorderLayout.NORTH);
        frame.add(processButton, BorderLayout.CENTER);
        frame.add(scrollPane, BorderLayout.SOUTH);
        
        frame.setVisible(true);
    }
}
