import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

// File processing logic
class StudentProcessor {

    // Reads student data from a file (skipping header)
    public static List<String[]> readStudentData(String inputFile) throws IOException {
        List<String[]> studentData = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile))) {
            reader.readLine(); // Skip header
            String line;
            while ((line = reader.readLine()) != null) {
                studentData.add(line.split(", "));
            }
        }
        return studentData;
    }

    // Calculates average marks and assigns grades
    public static List<String[]> calculateAverages(List<String[]> studentData) {
        List<String[]> updatedData = new ArrayList<>();
        for (String[] student : studentData) {
            int m1 = Integer.parseInt(student[2]);
            int m2 = Integer.parseInt(student[3]);
            int m3 = Integer.parseInt(student[4]);
            double avg = (m1 + m2 + m3) / 3.0;
            String grade = assignGrade(avg);
            updatedData.add(new String[]{student[0], student[1], student[2], student[3], student[4],
                                         String.format("%.2f", avg), grade});
        }
        return updatedData;
    }

    // Assigns a grade based on the average
    public static String assignGrade(double average) {
        if (average >= 90) return "A";
        if (average >= 80) return "B";
        if (average >= 70) return "C";
        if (average >= 60) return "D";
        return "F";
    }

    // Finds the top scorer from the updated data
    public static String findTopScorer(List<String[]> studentData) {
        String topStudent = "";
        double highestAvg = 0.0;
        String topGrade = "";
        for (String[] student : studentData) {
            double avg = Double.parseDouble(student[5]);
            if (avg > highestAvg) {
                highestAvg = avg;
                topStudent = student[1];
                topGrade = student[6];
            }
        }
        return "Top Scorer: " + topStudent + ", Average: " + String.format("%.2f", highestAvg) + ", Grade: " + topGrade;
    }

    // Writes the updated data (plus top scorer info) to an output file
    public static void writeToFile(List<String[]> studentData, String outputFile) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile))) {
            writer.write("ID, Name, Marks1, Marks2, Marks3, Average, Grade\n");
            for (String[] student : studentData) {
                writer.write(String.join(", ", student) + "\n");
            }
            writer.write(findTopScorer(studentData) + "\n");
        }
    }

    // Reads the entire content of a file as a String
    public static String readFileAsString(String filename) throws IOException {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append("\n");
            }
        }
        return sb.toString();
    }
}

// Swing GUI that uses the file processing logic
public class StudentProcessorGUI extends JFrame {
    private JTextField inputFileField, outputFileField;
    private JTextArea outputArea;
    private JButton processBtn;

    public StudentProcessorGUI() {
        setTitle("Student Processor");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(5, 5));

        // Input panel with file paths
        JPanel inputPanel = new JPanel(new GridLayout(3, 2, 5, 5));
        inputPanel.setBorder(BorderFactory.createTitledBorder("File Paths"));
        inputPanel.add(new JLabel("Input File:"));
        inputFileField = new JTextField("C:\\Users\\USER\\Documents\\Java project\\Java\\lab 7\\students.txt");
        inputPanel.add(inputFileField);
        inputPanel.add(new JLabel("Output File:"));
        outputFileField = new JTextField("students_with_avg.txt");
        inputPanel.add(outputFileField);
        processBtn = new JButton("Process File");
        inputPanel.add(processBtn);
        add(inputPanel, BorderLayout.NORTH);

        // Output area for displaying the result file content
        outputArea = new JTextArea(15, 50);
        outputArea.setEditable(false);
        add(new JScrollPane(outputArea), BorderLayout.CENTER);

        // Button event: process the file and display results
        processBtn.addActionListener(e -> processFile());

        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void processFile() {
        String inputFile = inputFileField.getText().trim();
        String outputFile = outputFileField.getText().trim();
        try {
            List<String[]> studentData = StudentProcessor.readStudentData(inputFile);
            List<String[]> updatedData = StudentProcessor.calculateAverages(studentData);
            StudentProcessor.writeToFile(updatedData, outputFile);
            String result = StudentProcessor.readFileAsString(outputFile);
            outputArea.setText(result);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(),
                                          "File Processing Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new StudentProcessorGUI());
    }
}
