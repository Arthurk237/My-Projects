import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class StudentProcessor {
    
    // Définition du fichier d'entrée contenant les données des étudiants
    static final String INPUT_FILE = "C:\\Users\\USER\\Documents\\Java project\\Java\\lab 7\\students.txt";

    // Définition du fichier de sortie où seront enregistrés les résultats
    static final String OUTPUT_FILE = "students_with_avg.txt";

    // Méthode pour lire et afficher le contenu d'un fichier
    public static void readAndDisplayFile(String filename) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line); // Affiche chaque ligne du fichier
            }
        } catch (IOException e) {
            System.out.println("Erreur lors de la lecture du fichier : " + e.getMessage());
        }
    }

    // Méthode pour calculer la moyenne des notes pour chaque étudiant
    public static List<String[]> calculateAverages(List<String[]> studentData) {
        List<String[]> updatedData = new ArrayList<>();
        for (String[] student : studentData) {
            // Extraction des notes à partir du fichier
            int marks1 = Integer.parseInt(student[2]);
            int marks2 = Integer.parseInt(student[3]);
            int marks3 = Integer.parseInt(student[4]);

            // Calcul de la moyenne
            double average = (marks1 + marks2 + marks3) / 3.0;

            // Attribution de la note en fonction de la moyenne
            String grade = assignGrade(average);

            // Ajout des nouvelles données mises à jour
            updatedData.add(new String[]{student[0], student[1], student[2], student[3], student[4], String.format("%.2f", average), grade});
        }
        return updatedData;
    }

    // Méthode pour attribuer une note en fonction de la moyenne obtenue
    public static String assignGrade(double average) {
        if (average >= 90) return "A";
        else if (average >= 80) return "B";
        else if (average >= 70) return "C";
        else if (average >= 60) return "D";
        else return "F";
    }

    // Méthode pour trouver l'étudiant ayant la meilleure moyenne
    public static String findTopScorer(List<String[]> studentData) {
        String topStudent = "";
        double highestAvg = 0.0;
        String topGrade = "";

        for (String[] student : studentData) {
            double avg = Double.parseDouble(student[5]); // Récupération de la moyenne
            if (avg > highestAvg) {
                highestAvg = avg;
                topStudent = student[1]; // Nom de l'étudiant avec la meilleure moyenne
                topGrade = student[6];   // Note correspondante
            }
        }
        return "Top Scorer: " + topStudent + ", Average Marks: " + String.format("%.2f", highestAvg) + ", Grade: " + topGrade;
    }

    // Méthode pour écrire les données mises à jour dans un fichier
    public static void writeToFile(List<String[]> studentData, String filename) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            // Écriture de l'en-tête du fichier
            writer.write("ID, Name, Marks1, Marks2, Marks3, Average, Grade\n");

            // Écriture des données des étudiants
            for (String[] student : studentData) {
                writer.write(String.join(", ", student) + "\n");
            }

            // Ajout des informations du meilleur étudiant
            writer.write(findTopScorer(studentData) + "\n");
        } catch (IOException e) {
            System.out.println("Erreur lors de l'écriture du fichier : " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        // Afficher le répertoire de travail actuel (utile pour le débogage)
        System.out.println("Répertoire de travail actuel : " + new File("").getAbsolutePath());

        List<String[]> studentData = new ArrayList<>();

        // Lecture des données du fichier d'entrée
        try (BufferedReader reader = new BufferedReader(new FileReader(INPUT_FILE))) {
            String line = reader.readLine(); // Ignorer l'en-tête
            while ((line = reader.readLine()) != null) {
                studentData.add(line.split(", ")); // Séparer les valeurs en fonction de la virgule
            }
        } catch (IOException e) {
            System.out.println("Erreur lors de la lecture du fichier : " + e.getMessage());
            return;
        }

        // Afficher les données originales
        System.out.println("Données originales :");
        readAndDisplayFile(INPUT_FILE);

        // Calculer les moyennes et attribuer les notes
        List<String[]> updatedData = calculateAverages(studentData);

        // Écrire les nouvelles données dans le fichier de sortie
        writeToFile(updatedData, OUTPUT_FILE);

        // Afficher le contenu du fichier mis à jour
        System.out.println("\nDonnées mises à jour :");
        readAndDisplayFile(OUTPUT_FILE);
    }
}
