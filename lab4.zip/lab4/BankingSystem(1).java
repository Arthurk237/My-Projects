
class BankAccount {
    private static int accountCounter = 1001; 
    protected String accountHolder; 
    protected int accountNumber; 
    protected double balance; 

    public BankAccount(String accountHolder, double balance) {
        this.accountHolder = accountHolder;
        this.accountNumber = accountCounter++;
        this.balance = balance;
    }

    // Méthode pour déposer de l'argent sur le compte
    public void deposit(double amount) {
        balance += amount;
        System.out.println("Dépôt de : $" + amount);
        System.out.println("Nouveau solde : $" + balance);
    }

    // Méthode de retrait (par défaut, le retrait n'est pas autorisé dans cette classe)
    public void withdraw(double amount) {
        System.out.println("Retrait non autorisé.");
    }

    public void displayDetails() {
        System.out.println("Titulaire du compte : " + accountHolder);
        System.out.println("Numéro du compte : " + accountNumber);
        System.out.println("Solde : $" + balance);
    }
}

// Classe représentant un compte d'épargne (hérite de BankAccount)
class SavingsAccount extends BankAccount {
    private final double interestRate; 

    public SavingsAccount(String accountHolder, double balance, double interestRate) {
        super(accountHolder, balance);
        this.interestRate = interestRate;
    }

    // Méthode pour retirer de l'argent du compte d'épargne
    @Override
    public void withdraw(double amount) {
        if (amount > balance) {
            System.out.println("Impossible de retirer : montant supérieur au solde !");
        } else {
            balance -= amount;
            System.out.println("Retrait de : $" + amount);
            System.out.println("Nouveau solde : $" + balance);
        }
    }

    // Surcharge de la méthode displayDetails pour inclure le taux d'intérêt
    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println("Taux d'intérêt : " + interestRate + "%");
    }
}

class CurrentAccount extends BankAccount {
    private final double overdraftLimit; // Limite de découvert autorisé

    public CurrentAccount(String accountHolder, double balance, double overdraftLimit) {
        super(accountHolder, balance);
        this.overdraftLimit = overdraftLimit;
    }

    // Méthode pour retirer de l'argent du compte courant en tenant compte du découvert
    @Override
    public void withdraw(double amount) {
        if (amount > (balance + overdraftLimit)) {
            System.out.println("Retrait refusé : dépassement de la limite de découvert !");
        } else {
            balance -= amount;
            System.out.println("Retrait de : $" + amount);
            System.out.println("Nouveau solde : $" + balance);
        }
    }

    // Surcharge de la méthode displayDetails pour afficher la limite de découvert
    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println("Limite de découvert : $" + overdraftLimit);
    }
}

public class BankingSystem {
    public static void main(String[] args) {
        SavingsAccount sa = new SavingsAccount("Cristiano Ronaldo", 5000, 3.5);
        CurrentAccount ca = new CurrentAccount("Kilian Mbappé", 2000, 1000);

        // Affichage des détails du compte d'épargne et test des transactions
        System.out.println("Détails du compte d'épargne :");
        sa.displayDetails();
        sa.deposit(500);
        sa.withdraw(6000); 

        System.out.println("\nDétails du compte courant :");
        // Affichage des détails du compte courant et test des transactions
        ca.displayDetails();
        ca.deposit(1000);
        ca.withdraw(1500); 
        ca.withdraw(5000); 
    }
}
