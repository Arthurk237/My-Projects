public class Person{
    private static int idcounter=1001;
    protected String name;
    protected int id;
    protected static final String university = "University Of Windsor";

    public Person(String name){
        this.name=name;
        this.id = idcounter++;
    }
    public void displayDetails(){
        System.out.println("Name:" +name);
        System.out.println("ID Number:" +id);
        System.out.println("University Name:" +university );
    }
}
// Classe représentant un étudiant, héritant de la classe Person
class Student extends Person{
    protected String department;
    protected double cgpa;

    public Student(String name, String department, double cgpa){
        super(name);
        this.department = department;
        this.cgpa=cgpa;
    }

    public void displayDetails(){
        super.displayDetails();
        System.out.println("Department: "+ department);
        System.out.println("CGPA: "+cgpa);
    }
}
// Classe représentant un étudiant diplômé, héritant de la classe Studen
class GraduateStudent extends Student{
    private String researchtopic;
    private String supervisor;

    public GraduateStudent(String name, String department, double cgpa, String researchtopic, String supervisor) {
        super(name,department,cgpa);
        this.researchtopic=researchtopic;
        this.supervisor = supervisor;
    }
    @Override
    public void displayDetails(){
        super.displayDetails();
        System.out.println("Research Topic:" + researchtopic);
        System.out.println("Supervisor: "+supervisor);
    }

    public static void main(String[] args) {
        Person p1 = new Person("Maradona");
        Student s1 = new Student("Lamin Yamal", "Computer Science", 3.8);
        GraduateStudent g1 = new GraduateStudent("Leo Messi", "Artificial Intelligence", 4.0, "Deep Learning for Vision", "Dr. Guardiola");

        System.out.println("Person Details:");
        p1.displayDetails();

        System.out.println("\nStudent Details:");
        s1.displayDetails();

        System.out.println("\nGraduate Student Details:");
        g1.displayDetails();
    }

}
