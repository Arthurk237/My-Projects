import javax.swing.*;
import java.awt.*;


class BankAccount {
    private static int accountCounter = 1001;

    protected String accountHolder; 
    protected int accountNumber; 
    protected double balance; 

    public BankAccount(String accountHolder, double balance) {
        this.accountHolder = accountHolder;
        this.accountNumber = accountCounter++;
        this.balance = balance;
    }

    // Deposit method
    public void deposit(double amount) {
        balance += amount;
        System.out.println("Deposit of : $" + amount);
        System.out.println("New Balance : $" + balance);
    }

    // Default withdraw method (not allowed)
    public void withdraw(double amount) {
        System.out.println("Withdrawal not allowed.");
        // In the base class, withdrawal is not allowed.
    }

    // Returns account details as a String
    public String getAccountDetails() {
        return "Account Holder: " + accountHolder + "\n" +
               "Account Number: " + accountNumber + "\n" +
               "Balance: $" + String.format("%.2f", balance);
    }
}

// SavingsAccount extends BankAccount and allows withdrawal
class SavingsAccount extends BankAccount {
    private final double interestRate; 

    public SavingsAccount(String accountHolder, double balance, double interestRate) {
        super(accountHolder, balance);
        this.interestRate = interestRate;
    }

    @Override
    public void withdraw(double amount) {
        if (amount > balance) {
            System.out.println("Withdrawal not allowed : amount superieur to balance!");
            // In a GUI you might show an error dialog; here we simply do nothing.
        } else {
            balance -= amount;
            System.out.println("Withdrawal of : $" + amount);
            System.out.println("New Balance : $" + balance);
        }
    }

    @Override
    public String getAccountDetails() {
        return super.getAccountDetails() + "\nInterest Rate: " + interestRate + "%";
    }
}

// CurrentAccount extends BankAccount and supports an overdraft limit for withdrawals
class CurrentAccount extends BankAccount {
    private final double overdraftLimit; 

    public CurrentAccount(String accountHolder, double balance, double overdraftLimit) {
        super(accountHolder, balance);
        this.overdraftLimit = overdraftLimit;
    }

    @Override
    public void withdraw(double amount) {
        if (amount > (balance + overdraftLimit)) {
            System.out.println("Withdrawal refused: Limite Surpassed!");
            // Withdrawal denied; do nothing here.
        } else {
            balance -= amount;
            System.out.println("Withdrawal of : $" + amount);
            System.out.println("New Balance : $" + balance);
        }
    }

    @Override
    public String getAccountDetails() {
        return super.getAccountDetails() + "\nOverdraft Limit: $" + String.format("%.2f", overdraftLimit);
    }
}

public class BankingGUI {
    private BankAccount currentAccount; // Stores the created account

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new BankingGUI().createAndShowGUI());
    }
    
    public void createAndShowGUI(){
        JFrame frame = new JFrame("Banking System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 500);
        frame.setLayout(new BorderLayout(10,10));

        // ----- Account Creation Panel -----
        JPanel creationPanel = new JPanel(new GridLayout(0, 2, 5, 5));
        creationPanel.setBorder(BorderFactory.createTitledBorder("Create Account"));

        // Account type selection
        creationPanel.add(new JLabel("Account Type:"));
        String[] accountTypes = {"Savings Account", "Current Account"};
        JComboBox<String> typeCombo = new JComboBox<>(accountTypes);
        creationPanel.add(typeCombo);

        // Account holder name
        creationPanel.add(new JLabel("Account Holder:"));
        JTextField holderField = new JTextField();
        creationPanel.add(holderField);

        // Initial balance
        creationPanel.add(new JLabel("Initial Balance:"));
        JTextField balanceField = new JTextField();
        creationPanel.add(balanceField);

        // Extra field (Interest Rate for Savings, Overdraft Limit for Current)
        JLabel extraLabel = new JLabel("Interest Rate (%):"); // default for Savings
        creationPanel.add(extraLabel);
        JTextField extraField = new JTextField();
        creationPanel.add(extraField);

        // Update extraLabel based on selected account type
        typeCombo.addActionListener(_ -> {
            String selected = (String) typeCombo.getSelectedItem();
            if(selected.equals("Savings Account")){
                extraLabel.setText("Interest Rate (%):");
            } else {
                extraLabel.setText("Overdraft Limit ($):");
            }
        });

        // Create Account Button
        JButton createButton = new JButton("Create Account");
        creationPanel.add(createButton);
        // Placeholder for layout symmetry
        creationPanel.add(new JLabel(""));

        // ----- Transaction Panel -----
        JPanel transactionPanel = new JPanel(new GridLayout(0, 3, 5, 5));
        transactionPanel.setBorder(BorderFactory.createTitledBorder("Transactions"));

        // Deposit
        transactionPanel.add(new JLabel("Deposit Amount:"));
        JTextField depositField = new JTextField();
        transactionPanel.add(depositField);
        JButton depositButton = new JButton("Deposit");
        depositButton.setEnabled(false);
        transactionPanel.add(depositButton);

        // Withdraw
        transactionPanel.add(new JLabel("Withdraw Amount:"));
        JTextField withdrawField = new JTextField();
        transactionPanel.add(withdrawField);
        JButton withdrawButton = new JButton("Withdraw");
        withdrawButton.setEnabled(false);
        transactionPanel.add(withdrawButton);

        // ----- Output Area -----
        JTextArea outputArea = new JTextArea();
        outputArea.setEditable(false);
        JScrollPane outputScroll = new JScrollPane(outputArea);
        outputScroll.setBorder(BorderFactory.createTitledBorder("Output"));

        // ----- Main Panel Arrangement -----
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.add(creationPanel, BorderLayout.NORTH);
        topPanel.add(transactionPanel, BorderLayout.SOUTH);

        frame.add(topPanel, BorderLayout.NORTH);
        frame.add(outputScroll, BorderLayout.CENTER);

        // ----- Event Handling -----

        // Create Account button event
        createButton.addActionListener(e -> {
            String type = (String) typeCombo.getSelectedItem();
            String holder = holderField.getText().trim();
            String balanceText = balanceField.getText().trim();
            String extraText = extraField.getText().trim();

            // Validate inputs
            if(holder.isEmpty() || balanceText.isEmpty() || extraText.isEmpty()){
                JOptionPane.showMessageDialog(frame, "Please fill in all fields.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            double initBalance;
            try {
                initBalance = Double.parseDouble(balanceText);
            } catch(NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Initial Balance must be a valid number.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Create the appropriate account type
            if(type.equals("Savings Account")){
                double interest;
                try {
                    interest = Double.parseDouble(extraText);
                } catch(NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Interest Rate must be a valid number.", "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                currentAccount = new SavingsAccount(holder, initBalance, interest);
            } else { // Current Account
                double overdraft;
                try {
                    overdraft = Double.parseDouble(extraText);
                } catch(NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Overdraft Limit must be a valid number.", "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                currentAccount = new CurrentAccount(holder, initBalance, overdraft);
            }

            // Enable transaction buttons now that an account is created
            depositButton.setEnabled(true);
            withdrawButton.setEnabled(true);

            // Display account details in the output area
            outputArea.append("Account Created Successfully:\n");
            outputArea.append(currentAccount.getAccountDetails() + "\n");
            outputArea.append("--------------------------\n");
        });

        // Deposit button event
        depositButton.addActionListener(e -> {
            if(currentAccount == null) {
                JOptionPane.showMessageDialog(frame, "Please create an account first.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            String depText = depositField.getText().trim();
            if(depText.isEmpty()){
                JOptionPane.showMessageDialog(frame, "Please enter a deposit amount.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            double depAmount;
            try {
                depAmount = Double.parseDouble(depText);
            } catch(NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Deposit amount must be a valid number.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            currentAccount.deposit(depAmount);
            outputArea.append("Deposited: $" + String.format("%.2f", depAmount) + "\n");
            outputArea.append(currentAccount.getAccountDetails() + "\n");
            outputArea.append("--------------------------\n");
        });

        // Withdraw button event
        withdrawButton.addActionListener(e -> {
            if(currentAccount == null) {
                JOptionPane.showMessageDialog(frame, "Please create an account first.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            String withText = withdrawField.getText().trim();
            if(withText.isEmpty()){
                JOptionPane.showMessageDialog(frame, "Please enter a withdrawal amount.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            double withAmount;
            try {
                withAmount = Double.parseDouble(withText);
            } catch(NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Withdrawal amount must be a valid number.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Before withdrawing, capture current balance to determine if withdrawal is allowed.
            double previousBalance = currentAccount.balance;
            currentAccount.withdraw(withAmount);
            if(currentAccount.balance == previousBalance) {
                outputArea.append("Withdrawal of $" + String.format("%.2f", withAmount) + " failed. Check account limits.\n");
            } else {
                outputArea.append("Withdrawed: $" + String.format("%.2f", withAmount) + "\n");
            }
            outputArea.append(currentAccount.getAccountDetails() + "\n");
            outputArea.append("--------------------------\n");
        });

        frame.setVisible(true);
    }
}
