import javax.swing.*;
import java.awt.*;

class Person {
    private static int idcounter = 1001;
    protected String name;
    protected int id;
    protected static final String university = "University Of Windsor";

    public Person(String name) {
        this.name = name;
        this.id = idcounter++;
    }

    // Original displayDetails method (prints to console)
    public void displayDetails() {
        System.out.println("Name:" + name);
        System.out.println("ID Number:" + id);
        System.out.println("University Name:" + university);
    }
    
    // Added method to return details as a string for GUI display
    public String getDetails(){
         return "Name: " + name + "\n" +
                "ID Number: " + id + "\n" +
                "University: " + university;
    }
}

class Student extends Person {
    protected String department;
    protected double cgpa;

    public Student(String name, String department, double cgpa) {
        super(name);
        this.department = department;
        this.cgpa = cgpa;
    }

    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println("Department: " + department);
        System.out.println("CGPA: " + cgpa);
    }
    
    @Override
    public String getDetails(){
         return super.getDetails() + "\n" +
                "Department: " + department + "\n" +
                "CGPA: " + cgpa;
    }
}

class GraduateStudent extends Student {
    private String researchtopic;
    private String supervisor;

    public GraduateStudent(String name, String department, double cgpa, String researchtopic, String supervisor) {
        super(name, department, cgpa);
        this.researchtopic = researchtopic;
        this.supervisor = supervisor;
    }
    
    @Override
    public void displayDetails(){
        super.displayDetails();
        System.out.println("Research Topic:" + researchtopic);
        System.out.println("Supervisor: " + supervisor);
    }
    
    @Override
    public String getDetails(){
         return super.getDetails() + "\n" +
                "Research Topic: " + researchtopic + "\n" +
                "Supervisor: " + supervisor;
    }
}
public class PersonGUI {
    public static void main(String[] args) {
        // Launch the GUI on the Event Dispatch Thread
        SwingUtilities.invokeLater(() -> new PersonGUI().createAndShowGUI());
    }
    
    public void createAndShowGUI(){
        JFrame frame = new JFrame("Person's University Information");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 500);
        frame.setLayout(new BorderLayout(10, 10));

        // ----- Input Panel -----
        JPanel inputPanel = new JPanel(new GridBagLayout());
        inputPanel.setBorder(BorderFactory.createTitledBorder("Create Person"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Row 0: Select Type
        gbc.gridx = 0; gbc.gridy = 0;
        inputPanel.add(new JLabel("Select The Type:"), gbc);
        String[] types = {"Person", "Student", "Graduate Student"};
        JComboBox<String> typeCombo = new JComboBox<>(types);
        gbc.gridx = 1; gbc.gridy = 0;
        inputPanel.add(typeCombo, gbc);

        // Row 1: Name (always required)
        gbc.gridx = 0; gbc.gridy = 1;
        inputPanel.add(new JLabel("Name:"), gbc);
        JTextField nameField = new JTextField(20);
        gbc.gridx = 1; gbc.gridy = 1;
        inputPanel.add(nameField, gbc);

        // Row 2: Department (only for Student and Graduate Student)
        gbc.gridx = 0; gbc.gridy = 2;
        JLabel deptLabel = new JLabel("Department:");
        inputPanel.add(deptLabel, gbc);
        JTextField deptField = new JTextField(20);
        gbc.gridx = 1; gbc.gridy = 2;
        inputPanel.add(deptField, gbc);

        // Row 3: CGPA (only for Student and Graduate Student)
        gbc.gridx = 0; gbc.gridy = 3;
        JLabel cgpaLabel = new JLabel("CGPA:");
        inputPanel.add(cgpaLabel, gbc);
        JTextField cgpaField = new JTextField(20);
        gbc.gridx = 1; gbc.gridy = 3;
        inputPanel.add(cgpaField, gbc);

        // Row 4: Research Topic (only for Graduate Student)
        gbc.gridx = 0; gbc.gridy = 4;
        JLabel researchLabel = new JLabel("Research Topic:");
        inputPanel.add(researchLabel, gbc);
        JTextField researchField = new JTextField(20);
        gbc.gridx = 1; gbc.gridy = 4;
        inputPanel.add(researchField, gbc);

        // Row 5: Supervisor (only for Graduate Student)
        gbc.gridx = 0; gbc.gridy = 5;
        JLabel supervisorLabel = new JLabel("Supervisor:");
        inputPanel.add(supervisorLabel, gbc);
        JTextField supervisorField = new JTextField(20);
        gbc.gridx = 1; gbc.gridy = 5;
        inputPanel.add(supervisorField, gbc);

        // Row 6: Create Button
        JButton createButton = new JButton("Create");
        gbc.gridx = 0; gbc.gridy = 6; gbc.gridwidth = 2;
        inputPanel.add(createButton, gbc);

        // Initially, hide extra fields for Student/Graduate Student
        deptLabel.setVisible(false);
        deptField.setVisible(false);
        cgpaLabel.setVisible(false);
        cgpaField.setVisible(false);
        researchLabel.setVisible(false);
        researchField.setVisible(false);
        supervisorLabel.setVisible(false);
        supervisorField.setVisible(false);

        // Update visibility based on type selection
        typeCombo.addActionListener(e -> {
            String selected = (String) typeCombo.getSelectedItem();
            if(selected.equals("Person")){
                deptLabel.setVisible(false);
                deptField.setVisible(false);
                cgpaLabel.setVisible(false);
                cgpaField.setVisible(false);
                researchLabel.setVisible(false);
                researchField.setVisible(false);
                supervisorLabel.setVisible(false);
                supervisorField.setVisible(false);
            } else if(selected.equals("Student")){
                deptLabel.setVisible(true);
                deptField.setVisible(true);
                cgpaLabel.setVisible(true);
                cgpaField.setVisible(true);
                researchLabel.setVisible(false);
                researchField.setVisible(false);
                supervisorLabel.setVisible(false);
                supervisorField.setVisible(false);
            } else if(selected.equals("Graduate Student")){
                deptLabel.setVisible(true);
                deptField.setVisible(true);
                cgpaLabel.setVisible(true);
                cgpaField.setVisible(true);
                researchLabel.setVisible(true);
                researchField.setVisible(true);
                supervisorLabel.setVisible(true);
                supervisorField.setVisible(true);
            }
            inputPanel.revalidate();
            inputPanel.repaint();
        });

        // ----- Output Area -----
        JTextArea outputArea = new JTextArea();
        outputArea.setEditable(false);
        JScrollPane outputScroll = new JScrollPane(outputArea);
        outputScroll.setBorder(BorderFactory.createTitledBorder("Output"));

        // ----- Main Frame Arrangement -----
        frame.add(inputPanel, BorderLayout.NORTH);
        frame.add(outputScroll, BorderLayout.CENTER);

        // ----- Event Handling for Create Button -----
        createButton.addActionListener(e -> {
            String type = (String) typeCombo.getSelectedItem();
            String name = nameField.getText().trim();
            if(name.isEmpty()){
                JOptionPane.showMessageDialog(frame, "Name is required.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            Person person = null;
            if(type.equals("Person")){
                person = new Person(name);
            } else if(type.equals("Student")){
                String dept = deptField.getText().trim();
                String cgpaText = cgpaField.getText().trim();
                if(dept.isEmpty() || cgpaText.isEmpty()){
                    JOptionPane.showMessageDialog(frame, "Department and CGPA are required for Student.", "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                double cgpa;
                try {
                    cgpa = Double.parseDouble(cgpaText);
                } catch(NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "CGPA must be a valid number.", "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                person = new Student(name, dept, cgpa);
            } else if(type.equals("Graduate Student")){
                String dept = deptField.getText().trim();
                String cgpaText = cgpaField.getText().trim();
                String research = researchField.getText().trim();
                String supervisor = supervisorField.getText().trim();
                if(dept.isEmpty() || cgpaText.isEmpty() || research.isEmpty() || supervisor.isEmpty()){
                    JOptionPane.showMessageDialog(frame, "All fields are required for Graduate Student.", "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                double cgpa;
                try {
                    cgpa = Double.parseDouble(cgpaText);
                } catch(NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "CGPA must be a valid number.", "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                person = new GraduateStudent(name, dept, cgpa, research, supervisor);
            }
            // Display the details in the output area
            outputArea.append("Created " + type + ":\n");
            outputArea.append(person.getDetails() + "\n");
            outputArea.append("--------------------------------------------------\n");
        });

        frame.setVisible(true);
    }
}