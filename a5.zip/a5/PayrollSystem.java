public class PayrollSystem {
    public static void displayEmployeeInfo(Employee emp) {
        System.out.println("Name: " + emp.getEmployeeName());
        System.out.println("ID: " + emp.getEmployeeID());
        System.out.println("Job Title: " + emp.getJobTitle());
        System.out.println("Address: " + emp.getAddress());
        System.out.println("Salary: " + emp.getSalary());
        System.out.println("Bonus %: " + emp.getBonusPercentage());
        System.out.println("Total Pay: " + emp.calculateTotalPay());
    }
}
