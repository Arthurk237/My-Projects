public class Employee {

    private String employeeName;
    private String employeeID; 
    private double salary; 
    private double bonusPercentage; 
    private String address; 
    private String jobTitle;

    public Employee() {
    }

    public Employee(String name, String id, double salary, double bonus, String addr, String title) {
        setEmployeeName(name);
        setEmployeeID(id);
        setSalary(salary);
        setBonusPercentage(bonus);
        setAddress(addr);
        setJobTitle(title);
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String name) {
        if (name != null && !name.trim().isEmpty()) {
            this.employeeName = name;
        }
    }

    public String getEmployeeID() {
        return employeeID;
    }

    public void setEmployeeID(String id) {
        if (id != null && id.length() == 6) {
            this.employeeID = id;
        }
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double sal) {
        if (sal >= 30000 && sal <= 200000) {
            this.salary = sal;
        }
    }

    public double getBonusPercentage() {
        return bonusPercentage;
    }

    public void setBonusPercentage(double bonus) {
        if (bonus >= 0 && bonus <= 100) {
            this.bonusPercentage = bonus;
        }
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String addr) {
        if (addr != null && addr.contains(" ")) {
            this.address = addr;
        }
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String title) {
        if (title != null &&
                (title.equals("Manager") ||
                        title.equals("Developer") ||
                        title.equals("Designer") ||
                        title.equals("Tester"))) {
            this.jobTitle = title;
        }
    }

    public double calculateTotalPay() {
        return salary + (salary * bonusPercentage / 100.0);
    }


}