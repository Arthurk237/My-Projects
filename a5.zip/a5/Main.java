public class Main {
    public static void main(String[] args) {
        Employee e1 = new Employee("Alice", "AB1234", 45000, 10, "123 King St", "Developer");

        // invalid at first
        Employee e2 = new Employee("Bob", "CD5678", 25000, 110, "456 Main St", "Tester");
        e2.setSalary(75000);    // set to a valid salary
        e2.setBonusPercentage(15);  // set to a valid bonus

        // Employee with invalid ID
        Employee e3 = new Employee("Charlie", "XYZ", 120000, 20, "789 Queen Ave", "Manager");
        // ID won't be set because "XYZ" is not 6 chars, so e3 will have a null ID

        // Demonstrate changing fields in e1
        System.out.println("Trying to set an invalid salary (25000) for first employee... (25000< 30000)");
        // < 30000
        e1.setSalary(25000); // invalid, should be ignored
        System.out.println("Current salary for first employee after invalid set: " + e1.getSalary());

        System.out.println("Trying to set an invalid bonus (120) for e1... (120 > 100)");
        // 0 <= bonus <= 100
        e1.setBonusPercentage(120); // invalid, should be ignored
        System.out.println("Current bonus for e1 after invalid set: " + e1.getBonusPercentage());

        // Display the final state of all employees
        System.out.println("\n-------------------------");
        System.out.println("\nFinal Employee Details");
        PayrollSystem.displayEmployeeInfo(e1);
        PayrollSystem.displayEmployeeInfo(e2);
        PayrollSystem.displayEmployeeInfo(e3);
    }
}
